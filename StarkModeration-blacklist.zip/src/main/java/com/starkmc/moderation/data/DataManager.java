package com.starkmc.moderation.data;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import org.bukkit.configuration.file.FileConfiguration;

public class DataManager {
   private final HikariDataSource pool;
   private final Map<String, DataManager.PunishmentEntry> banCache = new ConcurrentHashMap<>();
   private final Map<String, DataManager.PunishmentEntry> muteCache = new ConcurrentHashMap<>();
   private final Map<String, DataManager.PunishmentEntry> freezeCache = new ConcurrentHashMap<>();
   private final Map<String, DataManager.PunishmentEntry> blacklistCache = new ConcurrentHashMap<>();
   private final AtomicInteger frozenCount = new AtomicInteger();
   private final AtomicInteger mutedCount = new AtomicInteger();
   private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(2, r -> {
      Thread t = new Thread(r, "StarkMod-DB");
      t.setDaemon(true);
      return t;
   });

   public boolean anyFrozen() {
      return this.frozenCount.get() > 0;
   }

   public boolean anyMuted() {
      return this.mutedCount.get() > 0;
   }

   public DataManager(FileConfiguration cfg) {
      String host = cfg.getString("mysql.host", "localhost");
      int port = cfg.getInt("mysql.port", 3306);
      String db = cfg.getString("mysql.database", "starkmod");
      String user = cfg.getString("mysql.username", "root");
      String pass = cfg.getString("mysql.password", "");
      HikariConfig hc = new HikariConfig();
      hc.setJdbcUrl("jdbc:mysql://" + host + ":" + port + "/" + db + "?useSSL=false&autoReconnect=true&characterEncoding=utf8");
      hc.setUsername(user);
      hc.setPassword(pass);
      hc.setMaximumPoolSize(10);
      hc.setMinimumIdle(2);
      hc.setConnectionTimeout(10000L);
      hc.setIdleTimeout(600000L);
      hc.setMaxLifetime(1800000L);
      hc.setPoolName("StarkMod-Pool");
      this.pool = new HikariDataSource(hc);
      this.createTables();
      this.loadCache();
      this.scheduler.scheduleAtFixedRate(this::loadCache, 5L, 5L, TimeUnit.SECONDS);
   }

   private void createTables() {
      try {
         try (
            Connection c = this.pool.getConnection();
            Statement s = c.createStatement();
         ) {
            s.execute(
               "    CREATE TABLE IF NOT EXISTS sm_punishments (\n        type    VARCHAR(10)  NOT NULL,\n        player  VARCHAR(36)  NOT NULL,\n        expires BIGINT       NOT NULL DEFAULT -1,\n        reason  VARCHAR(512) NOT NULL DEFAULT 'no reason',\n        by_who  VARCHAR(36)  NOT NULL DEFAULT 'Console',\n        at_ms   BIGINT       NOT NULL,\n        PRIMARY KEY (type, player)\n    ) CHARACTER SET utf8mb4\n"
            );
            s.execute(
               "    CREATE TABLE IF NOT EXISTS sm_warns (\n        id      INT          NOT NULL AUTO_INCREMENT,\n        player  VARCHAR(36)  NOT NULL,\n        reason  VARCHAR(512) NOT NULL DEFAULT 'no reason',\n        by_who  VARCHAR(36)  NOT NULL DEFAULT 'Console',\n        at_ms   BIGINT       NOT NULL,\n        PRIMARY KEY (id),\n        INDEX idx_warn_player (player)\n    ) CHARACTER SET utf8mb4\n"
            );
            s.execute(
               "    CREATE TABLE IF NOT EXISTS sm_kicks (\n        id      INT          NOT NULL AUTO_INCREMENT,\n        player  VARCHAR(36)  NOT NULL,\n        reason  VARCHAR(512) NOT NULL DEFAULT 'no reason',\n        by_who  VARCHAR(36)  NOT NULL DEFAULT 'Console',\n        at_ms   BIGINT       NOT NULL,\n        PRIMARY KEY (id),\n        INDEX idx_kick_player (player)\n    ) CHARACTER SET utf8mb4\n"
            );
         }
      } catch (SQLException var9) {
         throw new RuntimeException("StarkMod DB init failed", var9);
      }
   }

   public void load() {
      this.scheduler.execute(this::loadCache);
   }

   private void loadCache() {
      try (
         Connection c = this.pool.getConnection();
         PreparedStatement ps = c.prepareStatement("SELECT type, player, expires, reason, by_who, at_ms FROM sm_punishments");
      ) {
         ResultSet rs = ps.executeQuery();
         Map<String, DataManager.PunishmentEntry> newBans = new HashMap<>();
         Map<String, DataManager.PunishmentEntry> newMutes = new HashMap<>();
         Map<String, DataManager.PunishmentEntry> newFreezes = new HashMap<>();
         Map<String, DataManager.PunishmentEntry> newBlacklist = new HashMap<>();
         long now = System.currentTimeMillis();

         while (rs.next()) {
            String type = rs.getString(1);
            String player = rs.getString(2);
            long exp = rs.getLong(3);
            if ("blacklist".equals(type)) {
               newBlacklist.put(player, new DataManager.PunishmentEntry(-1L, rs.getString(4), rs.getString(5), rs.getLong(6)));
            } else if (exp == -1L || exp > now) {
               DataManager.PunishmentEntry e = new DataManager.PunishmentEntry(exp, rs.getString(4), rs.getString(5), rs.getLong(6));
               switch (type) {
                  case "ban":
                     newBans.put(player, e);
                     break;
                  case "mute":
                     newMutes.put(player, e);
                     break;
                  case "freeze":
                     newFreezes.put(player, e);
               }
            }
         }

         this.banCache.clear();
         this.banCache.putAll(newBans);
         this.muteCache.clear();
         this.muteCache.putAll(newMutes);
         this.blacklistCache.clear();
         this.blacklistCache.putAll(newBlacklist);
         this.freezeCache.clear();
         this.freezeCache.putAll(newFreezes);
         this.frozenCount.set(newFreezes.size());
         this.mutedCount.set(newMutes.size());
      } catch (SQLException var20) {
         var20.printStackTrace();
      }
   }

   public void shutdown() {
      this.scheduler.shutdownNow();
      if (this.pool != null && !this.pool.isClosed()) {
         this.pool.close();
      }
   }

   private void upsertAsync(String type, String player, long expires, String reason, String by) {
      this.scheduler
         .execute(
            () -> {
               try (
                  Connection c = this.pool.getConnection();
                  PreparedStatement ps = c.prepareStatement(
                     "   INSERT INTO sm_punishments (type, player, expires, reason, by_who, at_ms)\n   VALUES (?, ?, ?, ?, ?, ?)\n   ON DUPLICATE KEY UPDATE expires=VALUES(expires), reason=VALUES(reason),\n                           by_who=VALUES(by_who), at_ms=VALUES(at_ms)\n"
                  );
               ) {
                  ps.setString(1, type);
                  ps.setString(2, player.toLowerCase());
                  ps.setLong(3, expires);
                  ps.setString(4, reason);
                  ps.setString(5, by);
                  ps.setLong(6, System.currentTimeMillis());
                  ps.executeUpdate();
               } catch (SQLException var15) {
                  var15.printStackTrace();
               }
            }
         );
   }

   private void deleteAsync(String type, String player) {
      this.scheduler.execute(() -> {
         try (
            Connection c = this.pool.getConnection();
            PreparedStatement ps = c.prepareStatement("DELETE FROM sm_punishments WHERE type=? AND player=?");
         ) {
            ps.setString(1, type);
            ps.setString(2, player.toLowerCase());
            ps.executeUpdate();
         } catch (SQLException var11) {
            var11.printStackTrace();
         }
      });
   }

   public boolean isBanned(String name) {
      DataManager.PunishmentEntry e = this.banCache.get(name.toLowerCase());
      if (e == null) {
         return false;
      } else if (e.isActive()) {
         return true;
      } else {
         this.banCache.remove(name.toLowerCase());
         this.deleteAsync("ban", name);
         return false;
      }
   }

   public void ban(String name, long durationMs, String reason, String by) {
      String key = name.toLowerCase();
      long now = System.currentTimeMillis();
      long exp = durationMs == -1L ? -1L : now + durationMs;
      this.banCache.put(key, new DataManager.PunishmentEntry(exp, reason, by, now));
      this.upsertAsync("ban", name, exp, reason, by);
   }

   public void unban(String name) {
      this.banCache.remove(name.toLowerCase());
      this.deleteAsync("ban", name);
   }

   // ---- Blacklist: permanent, separate from bans (never touched by unban / unbanall) ----
   public boolean isBlacklisted(String name) {
      return this.blacklistCache.containsKey(name.toLowerCase());
   }

   public void blacklist(String name, String reason, String by) {
      long now = System.currentTimeMillis();
      this.blacklistCache.put(name.toLowerCase(), new DataManager.PunishmentEntry(-1L, reason, by, now));
      this.upsertAsync("blacklist", name, -1L, reason, by);
   }

   public void unblacklist(String name) {
      this.blacklistCache.remove(name.toLowerCase());
      this.deleteAsync("blacklist", name);
   }

   public String getBlacklistReason(String n) {
      DataManager.PunishmentEntry e = this.blacklistCache.get(n.toLowerCase());
      return e != null ? e.reason() : "ɴᴏ ʀᴇᴀꜱᴏɴ";
   }

   public String getBlacklistBy(String n) {
      DataManager.PunishmentEntry e = this.blacklistCache.get(n.toLowerCase());
      return e != null ? e.by() : "Console";
   }

   public long getBlacklistAt(String n) {
      DataManager.PunishmentEntry e = this.blacklistCache.get(n.toLowerCase());
      return e != null ? e.at() : System.currentTimeMillis();
   }

   public Set<String> getBlacklistedPlayers() {
      return new java.util.TreeSet<>(this.blacklistCache.keySet());
   }

   public int getActiveBanCount() {
      long now = System.currentTimeMillis();
      return (int)this.banCache.values().stream().filter(e -> e.expires() == -1L || e.expires() > now).count();
   }

   /** Removes every active ban. Returns how many bans were active. */
   public int unbanAll() {
      int count = this.getActiveBanCount();
      this.banCache.clear();
      this.scheduler.execute(() -> {
         try (
            Connection c = this.pool.getConnection();
            PreparedStatement ps = c.prepareStatement("DELETE FROM sm_punishments WHERE type='ban'");
         ) {
            ps.executeUpdate();
         } catch (SQLException var11) {
            var11.printStackTrace();
         } finally {
            this.banCache.clear();
         }
      });
      return count;
   }

   public long getBanExpiry(String n) {
      DataManager.PunishmentEntry e = this.banCache.get(n.toLowerCase());
      return e != null ? e.expires() : 0L;
   }

   public String getBanReason(String n) {
      DataManager.PunishmentEntry e = this.banCache.get(n.toLowerCase());
      return e != null ? e.reason() : "ɴᴏ ʀᴇᴀꜱᴏɴ";
   }

   public String getBanBy(String n) {
      DataManager.PunishmentEntry e = this.banCache.get(n.toLowerCase());
      return e != null ? e.by() : "Console";
   }

   public long getBanAt(String n) {
      DataManager.PunishmentEntry e = this.banCache.get(n.toLowerCase());
      return e != null ? e.at() : 0L;
   }

   public DataManager.PunishmentEntry getBanEntry(String n) {
      return this.banCache.get(n.toLowerCase());
   }

   public boolean isMuted(String name) {
      DataManager.PunishmentEntry e = this.muteCache.get(name.toLowerCase());
      if (e == null) {
         return false;
      } else if (e.isActive()) {
         return true;
      } else {
         this.muteCache.remove(name.toLowerCase());
         this.mutedCount.decrementAndGet();
         this.deleteAsync("mute", name);
         return false;
      }
   }

   public void mute(String name, long durationMs, String reason, String by) {
      String key = name.toLowerCase();
      boolean hadMute = this.muteCache.containsKey(key);
      long now = System.currentTimeMillis();
      long exp = durationMs == -1L ? -1L : now + durationMs;
      this.muteCache.put(key, new DataManager.PunishmentEntry(exp, reason, by, now));
      if (!hadMute) {
         this.mutedCount.incrementAndGet();
      }

      this.upsertAsync("mute", name, exp, reason, by);
   }

   public void unmute(String name) {
      if (this.muteCache.remove(name.toLowerCase()) != null) {
         this.mutedCount.decrementAndGet();
      }

      this.deleteAsync("mute", name);
   }

   public long getMuteExpiry(String n) {
      DataManager.PunishmentEntry e = this.muteCache.get(n.toLowerCase());
      return e != null ? e.expires() : 0L;
   }

   public String getMuteReason(String n) {
      DataManager.PunishmentEntry e = this.muteCache.get(n.toLowerCase());
      return e != null ? e.reason() : "ɴᴏ ʀᴇᴀꜱᴏɴ";
   }

   public String getMuteBy(String n) {
      DataManager.PunishmentEntry e = this.muteCache.get(n.toLowerCase());
      return e != null ? e.by() : "Console";
   }

   public DataManager.PunishmentEntry getMuteEntry(String n) {
      return this.muteCache.get(n.toLowerCase());
   }

   public boolean isFrozen(String name) {
      DataManager.PunishmentEntry e = this.freezeCache.get(name.toLowerCase());
      if (e == null) {
         return false;
      } else if (e.isActive()) {
         return true;
      } else {
         this.freezeCache.remove(name.toLowerCase());
         this.frozenCount.decrementAndGet();
         this.deleteAsync("freeze", name);
         return false;
      }
   }

   public void freeze(String name, long durationMs, String by) {
      String key = name.toLowerCase();
      boolean hadFreeze = this.freezeCache.containsKey(key);
      long now = System.currentTimeMillis();
      long exp = durationMs == -1L ? -1L : now + durationMs;
      this.freezeCache.put(key, new DataManager.PunishmentEntry(exp, "N/A", by, now));
      if (!hadFreeze) {
         this.frozenCount.incrementAndGet();
      }

      this.upsertAsync("freeze", name, exp, "N/A", by);
   }

   public void unfreeze(String name) {
      if (this.freezeCache.remove(name.toLowerCase()) != null) {
         this.frozenCount.decrementAndGet();
      }

      this.deleteAsync("freeze", name);
   }

   public long getFreezeExpiry(String n) {
      DataManager.PunishmentEntry e = this.freezeCache.get(n.toLowerCase());
      return e != null ? e.expires() : -1L;
   }

   public String getFreezeBy(String n) {
      DataManager.PunishmentEntry e = this.freezeCache.get(n.toLowerCase());
      return e != null ? e.by() : "Console";
   }

   public Set<String> getFrozenPlayers() {
      long now = System.currentTimeMillis();
      Set<String> set = new HashSet<>();
      this.freezeCache.forEach((k, v) -> {
         if (v.expires() == -1L || v.expires() > now) {
            set.add(k);
         }
      });
      return Collections.unmodifiableSet(set);
   }

   public int warn(String name, String reason, String by) {
      this.scheduler.execute(() -> {
         try (
            Connection c = this.pool.getConnection();
            PreparedStatement ps = c.prepareStatement("INSERT INTO sm_warns (player, reason, by_who, at_ms) VALUES (?, ?, ?, ?)");
         ) {
            ps.setString(1, name.toLowerCase());
            ps.setString(2, reason);
            ps.setString(3, by);
            ps.setLong(4, System.currentTimeMillis());
            ps.executeUpdate();
         } catch (SQLException var12) {
            var12.printStackTrace();
         }
      });
      return this.getWarnCount(name) + 1;
   }

   public boolean removeWarn(String name, int id) {
      try {
         boolean var5;
         try (
            Connection c = this.pool.getConnection();
            PreparedStatement ps = c.prepareStatement("DELETE FROM sm_warns WHERE id=? AND player=?");
         ) {
            ps.setInt(1, id);
            ps.setString(2, name.toLowerCase());
            var5 = ps.executeUpdate() > 0;
         }

         return var5;
      } catch (SQLException var11) {
         var11.printStackTrace();
         return false;
      }
   }

   public int clearWarns(String name) {
      int count = this.getWarnCount(name);
      this.scheduler.execute(() -> {
         try (
            Connection c = this.pool.getConnection();
            PreparedStatement ps = c.prepareStatement("DELETE FROM sm_warns WHERE player=?");
         ) {
            ps.setString(1, name.toLowerCase());
            ps.executeUpdate();
         } catch (SQLException var10) {
            var10.printStackTrace();
         }
      });
      return count;
   }

   public List<WarnEntry> getWarns(String name) {
      List<WarnEntry> list = new ArrayList<>();

      try (
         Connection c = this.pool.getConnection();
         PreparedStatement ps = c.prepareStatement("SELECT id, reason, by_who, at_ms FROM sm_warns WHERE player=? ORDER BY id ASC");
      ) {
         ps.setString(1, name.toLowerCase());
         ResultSet rs = ps.executeQuery();

         while (rs.next()) {
            list.add(new WarnEntry(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getLong(4)));
         }
      } catch (SQLException var11) {
         var11.printStackTrace();
      }

      return Collections.unmodifiableList(list);
   }

   public int getWarnCount(String name) {
      try {
         int var5;
         try (
            Connection c = this.pool.getConnection();
            PreparedStatement ps = c.prepareStatement("SELECT COUNT(*) FROM sm_warns WHERE player=?");
         ) {
            ps.setString(1, name.toLowerCase());
            ResultSet rs = ps.executeQuery();
            var5 = rs.next() ? rs.getInt(1) : 0;
         }

         return var5;
      } catch (SQLException var10) {
         var10.printStackTrace();
         return 0;
      }
   }

   public int kick(String name, String reason, String by) {
      this.scheduler.execute(() -> {
         try (
            Connection c = this.pool.getConnection();
            PreparedStatement ps = c.prepareStatement("INSERT INTO sm_kicks (player, reason, by_who, at_ms) VALUES (?, ?, ?, ?)");
         ) {
            ps.setString(1, name.toLowerCase());
            ps.setString(2, reason);
            ps.setString(3, by);
            ps.setLong(4, System.currentTimeMillis());
            ps.executeUpdate();
         } catch (SQLException var12) {
            var12.printStackTrace();
         }
      });
      return this.getKickCount(name) + 1;
   }

   public List<KickEntry> getKicks(String name) {
      List<KickEntry> list = new ArrayList<>();

      try (
         Connection c = this.pool.getConnection();
         PreparedStatement ps = c.prepareStatement("SELECT id, reason, by_who, at_ms FROM sm_kicks WHERE player=? ORDER BY id ASC");
      ) {
         ps.setString(1, name.toLowerCase());
         ResultSet rs = ps.executeQuery();

         while (rs.next()) {
            list.add(new KickEntry(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getLong(4)));
         }
      } catch (SQLException var11) {
         var11.printStackTrace();
      }

      return Collections.unmodifiableList(list);
   }

   public int getKickCount(String name) {
      try {
         int var5;
         try (
            Connection c = this.pool.getConnection();
            PreparedStatement ps = c.prepareStatement("SELECT COUNT(*) FROM sm_kicks WHERE player=?");
         ) {
            ps.setString(1, name.toLowerCase());
            ResultSet rs = ps.executeQuery();
            var5 = rs.next() ? rs.getInt(1) : 0;
         }

         return var5;
      } catch (SQLException var10) {
         var10.printStackTrace();
         return 0;
      }
   }

   public Map<String, DataManager.PunishmentEntry> getAllBanned() {
      return Collections.unmodifiableMap(new LinkedHashMap<>(this.banCache));
   }

   public Map<String, DataManager.PunishmentEntry> getAllMuted() {
      return Collections.unmodifiableMap(new LinkedHashMap<>(this.muteCache));
   }

   public Map<String, List<WarnEntry>> getAllWarnsGrouped() {
      Map<String, List<WarnEntry>> map = new LinkedHashMap<>();

      try (
         Connection c = this.pool.getConnection();
         PreparedStatement ps = c.prepareStatement("SELECT player, id, reason, by_who, at_ms FROM sm_warns ORDER BY player, id ASC");
      ) {
         ResultSet rs = ps.executeQuery();

         while (rs.next()) {
            map.computeIfAbsent(rs.getString(1), k -> new ArrayList<>()).add(new WarnEntry(rs.getInt(2), rs.getString(3), rs.getString(4), rs.getLong(5)));
         }
      } catch (SQLException var10) {
         var10.printStackTrace();
      }

      map.replaceAll((k, v) -> Collections.unmodifiableList((List<? extends WarnEntry>)v));
      return Collections.unmodifiableMap(map);
   }

   public List<WarnEntry> getAllWarns() {
      List<WarnEntry> list = new ArrayList<>();

      try (
         Connection c = this.pool.getConnection();
         PreparedStatement ps = c.prepareStatement("SELECT id, reason, by_who, at_ms FROM sm_warns ORDER BY id ASC");
      ) {
         ResultSet rs = ps.executeQuery();

         while (rs.next()) {
            list.add(new WarnEntry(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getLong(4)));
         }
      } catch (SQLException var10) {
         var10.printStackTrace();
      }

      return Collections.unmodifiableList(list);
   }

   public Map<String, List<KickEntry>> getAllKicksGrouped() {
      Map<String, List<KickEntry>> map = new LinkedHashMap<>();

      try (
         Connection c = this.pool.getConnection();
         PreparedStatement ps = c.prepareStatement("SELECT player, id, reason, by_who, at_ms FROM sm_kicks ORDER BY player, id ASC");
      ) {
         ResultSet rs = ps.executeQuery();

         while (rs.next()) {
            map.computeIfAbsent(rs.getString(1), k -> new ArrayList<>()).add(new KickEntry(rs.getInt(2), rs.getString(3), rs.getString(4), rs.getLong(5)));
         }
      } catch (SQLException var10) {
         var10.printStackTrace();
      }

      map.replaceAll((k, v) -> Collections.unmodifiableList((List<? extends KickEntry>)v));
      return Collections.unmodifiableMap(map);
   }

   public record PunishmentEntry(long expires, String reason, String by, long at) {
      public boolean isActive() {
         return this.expires == -1L || System.currentTimeMillis() < this.expires;
      }
   }
}
